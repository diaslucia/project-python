 class Persona:
    def __init__(sefl, name, email):
      self.name = name
      self.email: email
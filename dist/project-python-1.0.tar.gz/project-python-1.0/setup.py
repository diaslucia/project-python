from setuptools import setup

setup(
    name="project-python",
    version= "1.0",
    description= "",
    author= "Lucia Dias",
    author_email= "luciadias.dev@gmail.com",
    packages= ["package"]
)
